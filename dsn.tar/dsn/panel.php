<?php
    header("Access-Control-Allow-Origin: *"); 
    
    if($_SERVER['REQUEST_METHOD'] === 'POST'){
        $ip1 = $_SERVER['REMOTE_ADDR'];
        $file = "./$ip1.txt";
        if (file_exists($file)) {
            $myfile = fopen($file, "r");
            if ($myfile) {
                echo json_encode(["msg" => fread($myfile,filesize("./$ip1.txt"))]);
                fclose($myfile);
                unlink($file);
            }
        } else {
            echo json_encode(["error" => "Not found", "ip" => $ip1]);
        }
    }

    if(isset($_GET["response"]) && isset($_GET["ip"])){
        $res = $_GET["response"];
        $ip = $_GET["ip"];
        $resfile = "./$ip.txt";
        
      if(file_exists($resfile)){
            unlink($resfile);
            $handle = fopen($resfile, "a");
            fwrite($handle, $res);
            fclose($handle);
        }
        else {
            $handle = fopen($resfile, "a");
            fwrite($handle, $res);
            fclose($handle);
        }
        
        echo "<h2 style='font-family: 'Segoe UI', sans-serif'; font-weight: 500;> ✅ redirected to $res...</h2>";
    }
    
	
?>

